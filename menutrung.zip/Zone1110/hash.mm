#import "Zone1110.h"
#import "encrypt.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
@interface CTDOTECH : NSObject
@end
@implementation CTDOTECH

static Zone1110 *extraInfo;

NSString * const __contact = NSSENCRYPT("Liên hệ"); // Nội dung nút liên hệ
NSString * const __Confirm = NSSENCRYPT("Xác nhận"); // Nội dung nút xác nhận
 //token package
UIButton* InvisibleMenuButton;
UIButton* VisibleMenuButton;
UITextField* hideRecordTextfield;
UIView* hideRecordView;

+ (void)load {
    [super load];

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

    Zone1110 *api = [[Zone1110 alloc] init];

    extraInfo = [Zone1110 new];
        
    [api setToken:@"Hole30601-0CTzFb6KBvdVSiwYhIeyqoQ4c9X5EP8g10a391760418e2cb9ff26d4e83e65859"];

[api paid:^{
// Gọi hàm mở menu ở đây 
    }];
});
}



@end