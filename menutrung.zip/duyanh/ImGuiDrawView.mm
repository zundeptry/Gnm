#include "LoadView/Includes.h"
#import "Security/oxorany/oxorany_include.h"
#import "Security/oxorany/oxorany.h"
#include <Foundation/Foundation.h>
#include <libgen.h>
#include <mach-o/dyld.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>
#include <mach/vm_page_size.h>
#include <unistd.h>
#include <array>
#include <deque>
#include <map>
#include <vector>
#import "imgui/Il2cpp.h"
#import "LoadView/Icon.h"
#import "imgui/stb_image.h"
#include "hook/hook.h"
#import "imgui/CaptainHook.h"
#import "imgui/imgui_additional.h"
#include <CoreFoundation/CoreFoundation.h>
#import "mahoa.h"
#import "cac.h"
#include "hack/Vector3.h"
#include "hack/Vector2.h"
#include "hack/Quaternion.h"
#include "hack/Monostring.h"
#include "Esp.h"
#import "LoadView/CTCheckbox.h"
#define kWidth [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale

CTCheckbox *checkbox1;
CTCheckbox *checkbox2;
UIWindow *mainWindow;
UIButton *menuView;
using namespace IL2Cpp;
@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
- (void)ghost;
- (void)removeGhost; 
- (void)switchIsChanged:(UISwitch *)SW1;
@end
@implementation ImGuiDrawView

ImFont* _espFont;
ImFont *_iconFont;

BOOL hasGhostBeenDrawn = NO;
static std::string selectedStyle = "DarkMode";

bool camcao = false;

float CAMCAO(void *instance) {
     if (camcao) {
         return 100.0;
     }
}

bool CHUV = false;
float chuV(void *instance) {
     if (CHUV) {
         return 100.0;
     }
}
bool camxa = false; 
float CamXa(void *instance) {
    if (camxa) {
        return 1; 
    } else {
        return 1;
    }
}

bool Norecoill = false;
int abc(void *instance) {
     if (Norecoill) {
         return 1;
     }else{
    return 1;
}
}

- (void)ghost {  
    mainWindow = [[UIApplication sharedApplication] keyWindow];  

//Checkbox 1
checkbox1 = [[CTCheckbox alloc] initWithFrame:CGRectMake(50, 25, 25.0, 25.0)];
[checkbox1 addTarget:self action:@selector(checkboxDidChange:) forControlEvents:UIControlEventValueChanged];
//màu hiển thị
[checkbox1 setColor:[UIColor colorWithRed: 1 green: 0 blue: 0 alpha: 1.0] forControlState:UIControlStateNormal];
//màu khi chạm vào
[checkbox1 setColor:[UIColor colorWithRed: 1 green: 0 blue: 0 alpha: 0.5] forControlState:UIControlStateDisabled];
[mainWindow addSubview:checkbox1];

    UILabel *myLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(75, 28, 200.0, 20.0)];
myLabel1.textColor = [UIColor whiteColor];
myLabel1.font = [UIFont systemFontOfSize:12.5];
myLabel1.numberOfLines = 1;
myLabel1.text = [NSString stringWithFormat:@"2 Súng"];
myLabel1.textAlignment = NSTextAlignmentLeft;
myLabel1.shadowOffset = CGSizeMake(1.0,1.0); 
//myLabel1.backgroundColor = [UIColor clearColor];
[mainWindow addSubview:myLabel1];

//Checkbox 2
checkbox2 = [[CTCheckbox alloc] initWithFrame:CGRectMake(50, 52, 25.0, 25.0)];
[checkbox2 addTarget:self action:@selector(checkboxDidChange1:) forControlEvents:UIControlEventValueChanged];
//màu hiển thị
[checkbox2 setColor:[UIColor colorWithRed: 1 green: 0 blue: 0 alpha: 1.0] forControlState:UIControlStateNormal];
//Màu khi ấn vào
[checkbox2 setColor:[UIColor colorWithRed: 1 green: 0 blue: 0 alpha: 0.5] forControlState:UIControlStateDisabled];
[mainWindow addSubview:checkbox2];

    UILabel *myLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(75, 55, 200.0, 20.0)];
myLabel2.textColor = [UIColor whiteColor];
myLabel2.font = [UIFont systemFontOfSize:12.5];
myLabel2.numberOfLines = 1;
myLabel2.text = [NSString stringWithFormat:@"Bắn Di Chuyển"];
myLabel2.textAlignment = NSTextAlignmentLeft;
myLabel2.shadowOffset = CGSizeMake(1.0,1.0); 
//myLabel1.backgroundColor = [UIColor clearColor];
[mainWindow addSubview:myLabel2];

    if (!menuView) {  
        // Tạo menuView với nền tròn màu đen nhạt  
        menuView = [UIButton buttonWithType:UIButtonTypeCustom];  
        menuView.frame = CGRectMake(305, 265, 50, 50);  
        menuView.layer.cornerRadius = menuView.bounds.size.width / 2; // Hình tròn  
        menuView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.6]; // Nền đen nhạt  
        menuView.alpha = 1.0f;  

        // Đảm bảo chỉ thêm vào cửa sổ chính một lần  
        [mainWindow addSubview:menuView];  

        // Thêm sự kiện kéo nút sử dụng UIPanGestureRecognizer  
        UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];  
        [menuView addGestureRecognizer:panGesture];  

        // Thêm nhãn cho trạng thái Aimbot  
        UILabel *aimLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 50, 50)]; // Kích thước 50x50 cho chữ
        aimLabel.font = [UIFont fontWithName:@"CourierNewPS-BoldMT" size:16];  
        aimLabel.textAlignment = NSTextAlignmentCenter; // Canh giữa  
        aimLabel.backgroundColor = [UIColor clearColor]; // Không có nền  
        aimLabel.tag = 100; // Gán thẻ để truy xuất sau  

        // Căn giữa nhãn trong menuView  
        aimLabel.center = CGPointMake(menuView.bounds.size.width / 2, menuView.bounds.size.height / 2);  

        // Thêm nhãn vào menuView  
        [menuView addSubview:aimLabel];  

        // Đặt văn bản cho nhãn  
        aimLabel.text = @"AIM";   
        aimLabel.textColor = [UIColor redColor]; // Màu chữ bắt đầu là đỏ (tắt)  

        // Tạo nút "AIM" nhỏ lại (kích thước 30x30 thay vì 70x70)  
        UIButton *aimButton = [UIButton buttonWithType:UIButtonTypeCustom];  
        aimButton.frame = CGRectMake(0, 0, 30, 30); // Kích thước nút nhỏ lại  
        aimButton.layer.cornerRadius = aimButton.bounds.size.width / 2; // Vẫn giữ hình tròn  
        aimButton.backgroundColor = [UIColor clearColor]; // Nền trong suốt  
        [aimButton addTarget:self action:@selector(switchIsChanged:) forControlEvents:UIControlEventTouchUpInside];  

        // Căn giữa nút "AIM" nhỏ trong menuView  
        aimButton.center = CGPointMake(menuView.bounds.size.width / 2, menuView.bounds.size.height / 2);  

        // Thêm nút vào menuView  
        [menuView addSubview:aimButton];  

        hasGhostBeenDrawn = YES; // Đánh dấu menu đã được vẽ  
    }  
}
- (void)activehack {
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    CGFloat rectWidth = screenWidth * 0.26;
    CGFloat rectHeight = screenHeight * 0.15;
    CGFloat rectX = screenWidth * 1.0;
    CGFloat rectY1 = screenHeight * 0.10;
    CGFloat rectY2 = screenHeight * 0.10;
    UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    UIView *rect2 = [[UIView alloc] initWithFrame:CGRectMake(rectX, rectY2, 0, rectHeight)];
    rect2.backgroundColor = [UIColor blackColor];
    [mainWindow addSubview:rect2];
    UIView *rect1 = [[UIView alloc] initWithFrame:CGRectMake(rectX, rectY1, 0, rectHeight)];
    rect1.backgroundColor = [UIColor colorWithRed:0.97 green:0.13 blue:0.28 alpha:1.0]; // F72047 color
    [mainWindow addSubview:rect1];

    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 30)];
    label1.text = @"CHEAT BY NGOCBACH";
    label1.textAlignment = NSTextAlignmentLeft;
    label1.font = [UIFont fontWithName:@"AvenirNext-Bold" size:13];
    label1.textColor = [UIColor colorWithRed:0.97 green:0.13 blue:0.28 alpha:1.0]; // F72047 color
    label1.alpha = 0; // Initially hidden
    label1.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 - 15); 
    [mainWindow addSubview:label1];

    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 30)];
    label2.text = @"YOUR LICENSE HAS BEEN ACTIVED !!! LETS PLAY ";
    label2.textAlignment = NSTextAlignmentLeft;
    label2.font = [UIFont fontWithName:@"AvenirNext-Bold" size:8];
    label2.textColor = [UIColor colorWithRed:0.63 green:0.09 blue:0.19 alpha:1.0]; // A61630 color
    label2.alpha = 0; 
    label2.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 - 5); 
    [mainWindow addSubview:label2];

    UILabel *label3 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 40)];
    label3.text = @"TURN ON AIMBOT | RUNNING";
    label3.textAlignment = NSTextAlignmentLeft;
    label3.font = [UIFont fontWithName:@"AvenirNext-Bold" size:18];
    label3.alpha = 0;
     label3.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 + 13); 
    [mainWindow addSubview:label3];
    [mainWindow bringSubviewToFront:label1];
    [mainWindow bringSubviewToFront:label2];
    [mainWindow bringSubviewToFront:label3];
    [mainWindow bringSubviewToFront:rect1];
    [UIView animateWithDuration:0.5 animations:^{
        rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, rectWidth, rectHeight); 
        rect2.frame = CGRectMake(rectX - rectWidth + 0.5, rectY2, rectWidth, rectHeight);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.15 delay:0.0 options:0 animations:^{
            rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, screenWidth * 0.005, rectHeight);
        } completion:^(BOOL finished) {
            label1.alpha = 1;
            label2.alpha = 1;
            label3.alpha = 1;
            [UIView animateWithDuration:0.5 delay:6.0 options:0 animations:^{
                rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, rectWidth, rectHeight);
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.15 delay:0.0 options:0 animations:^{
                    rect1.frame = CGRectMake(rectX, rectY1, 0, rectHeight);
                    rect2.frame = CGRectMake(rectX, rectY2, 0, rectHeight);
                    label1.alpha = 0; 
                    label2.alpha = 0;
                    label3.alpha = 0;
                } completion:nil];
            }];
        }];
    }];
}
- (void)activehack1 {
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
    CGFloat rectWidth = screenWidth * 0.26;
    CGFloat rectHeight = screenHeight * 0.15;
    CGFloat rectX = screenWidth * 1.0;
    CGFloat rectY1 = screenHeight * 0.10;
    CGFloat rectY2 = screenHeight * 0.10;
    UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    UIView *rect2 = [[UIView alloc] initWithFrame:CGRectMake(rectX, rectY2, 0, rectHeight)];
    rect2.backgroundColor = [UIColor blackColor];
    [mainWindow addSubview:rect2];
    UIView *rect1 = [[UIView alloc] initWithFrame:CGRectMake(rectX, rectY1, 0, rectHeight)];
    rect1.backgroundColor = [UIColor colorWithRed:0.97 green:0.13 blue:0.28 alpha:1.0]; // F72047 color
    [mainWindow addSubview:rect1];

    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 30)];
    label1.text = @"CHEAT BY NGOCBACH";
    label1.textAlignment = NSTextAlignmentLeft;
    label1.font = [UIFont fontWithName:@"AvenirNext-Bold" size:13];
    label1.textColor = [UIColor colorWithRed:0.97 green:0.13 blue:0.28 alpha:1.0]; // F72047 color
    label1.alpha = 0; // Initially hidden
    label1.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 - 15); 
    [mainWindow addSubview:label1];

    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 30)];
    label2.text = @"YOUR LICENSE HAS BEEN ACTIVED !!! LETS PLAY ";
    label2.textAlignment = NSTextAlignmentLeft;
    label2.font = [UIFont fontWithName:@"AvenirNext-Bold" size:8];
    label2.textColor = [UIColor colorWithRed:0.63 green:0.09 blue:0.19 alpha:1.0]; // A61630 color
    label2.alpha = 0; 
    label2.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 - 5); 
    [mainWindow addSubview:label2];

    UILabel *label3 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 40)];
    label3.text = @"TURN ON MENU | RUNNING";
    label3.textAlignment = NSTextAlignmentLeft;
    label3.font = [UIFont fontWithName:@"AvenirNext-Bold" size:18];
    label3.alpha = 0;
     label3.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 + 13); 
    [mainWindow addSubview:label3];
    [mainWindow bringSubviewToFront:label1];
    [mainWindow bringSubviewToFront:label2];
    [mainWindow bringSubviewToFront:label3];
    [mainWindow bringSubviewToFront:rect1];
    [UIView animateWithDuration:0.5 animations:^{
        rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, rectWidth, rectHeight); 
        rect2.frame = CGRectMake(rectX - rectWidth + 0.5, rectY2, rectWidth, rectHeight);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.15 delay:0.0 options:0 animations:^{
            rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, screenWidth * 0.005, rectHeight);
        } completion:^(BOOL finished) {
            label1.alpha = 1;
            label2.alpha = 1;
            label3.alpha = 1;
            [UIView animateWithDuration:0.5 delay:9.0 options:0 animations:^{
                rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, rectWidth, rectHeight);
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.15 delay:0.0 options:0 animations:^{
                    rect1.frame = CGRectMake(rectX, rectY1, 0, rectHeight);
                    rect2.frame = CGRectMake(rectX, rectY2, 0, rectHeight);
                    label1.alpha = 0; 
                    label2.alpha = 0;
                    label3.alpha = 0;
                } completion:nil];
            }];
        }];
    }];
}

// Phương thức gọi khi Aimbot bị bật/tắt  
- (void)switchIsChanged:(UIButton *)button {  
    dispatch_async(dispatch_get_main_queue(), ^{  
        UILabel *aimLabel = (UILabel *)[[button superview] viewWithTag:100]; // Tìm nhãn  

        if ([aimLabel.textColor isEqual:[UIColor redColor]]) {  
            // Bật Aimbot  
            Aimbot = true;  
            aimLabel.textColor = [UIColor greenColor]; // Đổi màu chữ thành xanh  
        } else {  
            // Tắt Aimbot  
            Aimbot = false;  
            aimLabel.textColor = [UIColor redColor]; // Đổi màu chữ thành đỏ  
        }  
    });  
}  

- (void)checkboxDidChange:(CTCheckbox *)checkbox1
{
    if (checkbox1.checked) {
Norecoill = true;
            
        } else{
Norecoill = false;
}

    }

- (void)checkboxDidChange1:(CTCheckbox *)checkbox2
{
    if (checkbox2.checked) {
camxa = true;
        } else{
camxa = false;
}

    }

// Phương thức gọi khi xóa menu  
- (void)removeGhost {  
    if (menuView) {  
        [menuView removeFromSuperview];  
        menuView = nil;  
        hasGhostBeenDrawn = NO;  
    }  
}  

// Phương thức xử lý kéo  
- (void)handlePan:(UIPanGestureRecognizer *)gesture {  
    CGPoint translation = [gesture translationInView:mainWindow];  
    CGPoint newCenter = CGPointMake(gesture.view.center.x + translation.x, gesture.view.center.y + translation.y);  
    gesture.view.center = newCenter; // Cập nhật vị trí của nút  
    [gesture setTranslation:CGPointZero inView:mainWindow]; // Đặt lại translation về 0  
} 

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

//style
    ImFontConfig config;
    ImFontConfig icons_config;
    config.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2;
    icons_config.OversampleV = 2;

    static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };

    NSString *fontPath = nssoxorany("/System/Library/Fonts/Core/AvenirNext.ttc");

    _espFont = io.Fonts->AddFontFromFileTTF(fontPath.UTF8String, 30.f, &config, io.Fonts->GetGlyphRangesVietnamese());

    _iconFont = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 19.0f, &icons_config, icons_ranges);

    _iconFont->FontSize = 5;
    io.FontGlobalScale = 0.5f;

    ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
}

+ (BOOL)isMenuShowing {
    return MenDeal;
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}



- (void)loadView
{
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self activehack1];
  

    
    self.mtkView.device = self.device;
    if (!self.mtkView.device) {
        return;
    }
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;

    void* address[] = {  
(void*)getRealOffset(ENCRYPTOFFSET("0x1052A23A0")),         
(void*)getRealOffset(ENCRYPTOFFSET("0x10529A408")),               (void*)getRealOffset(ENCRYPTOFFSET("0x1040D6610")),         (void*)getRealOffset(ENCRYPTOFFSET("0x1040D18E0")),         (void*)getRealOffset(ENCRYPTOFFSET("0x1052620FC")),         (void*)getRealOffset(ENCRYPTOFFSET("0x103E526F0"))
    };
    void* function[] = {
        (void*)CamXa,
        (void*)Update,
        (void*)CAMCAO,
        (void*)abc,
        (void*)OnDestroy,
        (void*)chuV
    };
    hook(address, function, 6);
_GetHeadPositions = (void*(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BECB8"));
_newHipMods = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BEE08"));
_GetLeftAnkleTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF13C"));
_GetRightAnkleTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF1E0"));
_GetLeftToeTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF284"));
_GetRightToeTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF328"));
_getLeftHandTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C0E8"));
_getRightHandTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C194"));
_getLeftForeArmTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C238"));
_getRightForeArmTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C2DC"));

    Local = (bool (*)(void *))getRealOffset(ENCRYPTOFFSET("0x105258C80"));                              
    Team = (bool (*)(void *))getRealOffset(ENCRYPTOFFSET("0x10526D118"));                               
    get_CurHP = (int (*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052A8A30"));                           
    get_MaxHP = (int(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052A8AD8"));                            
    get_position = (Vector3(*)(void *))getRealOffset(ENCRYPTOFFSET("0x105F3D46C"));                     
    WorldToViewpoint = (Vector3(*)(void *, Vector3, int))getRealOffset(ENCRYPTOFFSET("0x105EF6394"));  
    get_main = (void *(*)())getRealOffset(ENCRYPTOFFSET("0x105EF6D08"));                                
    get_transform = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x105EF8D78"));                     

}
static bool MenDeal = false;
static bool StreamerMode = true;

- (void)drawInMTKView:(MTKView*)view
{

    hideRecordTextfield.secureTextEntry = StreamerMode;

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
        
        if (MenDeal == true) 
        {
            [self.view setUserInteractionEnabled:YES];
            [self.view.superview setUserInteractionEnabled:YES];
            [menuTouchView setUserInteractionEnabled:YES];
        } 
        else if (MenDeal == false) 
        {
           
            [self.view setUserInteractionEnabled:NO];
            [self.view.superview setUserInteractionEnabled:NO];
            [menuTouchView setUserInteractionEnabled:NO];

        }

        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil)
        {
            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            [renderEncoder pushDebugGroup:nssoxorany("ImGui Jane")];

            ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();

            CGFloat width = 480;
            CGFloat height = 330;
            ImGui::SetNextWindowPos(ImVec2((kWidth - width) / 2, (kHeight - height) / 2), ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_FirstUseEver);



            
if (MenDeal) {
            ImGui::Begin("Menu Hack No Jailbreak By NgocBach", &MenDeal);
            if (ImGui::BeginTabBar("TabBar")){
            if (ImGui::BeginTabItem(ICON_FA_HOUSE "HOME"))
                    {

ImGui::BeginGroupPanel("ESP", ImVec2(0, 0));
                ImGui::Checkbox(" Bật ESP", &ESPEnable);
ImGui::SameLine(); 
ImGui::SliderFloat("Khoảng Cách ESP", &sliderDistanceValue, 0.0f, 999.0f);

ImGui::Checkbox("Line", &ESPLine);
ImGui::SameLine(); 
ImGui::Checkbox("Cảnh Báo", &ESPArrow);
ImGui::SameLine(); 
ImGui::Checkbox("3DBox", &vailon);

                ImGui::Checkbox("Xương", &bone);
ImGui::SameLine(); 
ImGui::Checkbox("Box", &ESPBox);
ImGui::SameLine(); 
ImGui::Checkbox("Name", &ESPName); 
                
ImGui::Checkbox("Health", &ESPHealth); 
ImGui::SameLine(); 
ImGui::Checkbox("Count", &ESPCount);                 
ImGui::EndGroupPanel();
ImGui::BeginGroupPanel("AIMBOT", ImVec2(0, 0));
ImGui::Checkbox("AIMBOT", &cc);
                DrawAimbotTab();
ImGui::Checkbox("FOV", &Fov);

ImGui::SliderFloat("", &circle_size, 0.0f, 360.0f);

ImGui::EndGroupPanel();
ImGui::Separator();

ImGui::BeginGroupPanel("CHỨC NĂNG", ImVec2(0, 0));
                        
ImGui::TextColored(ImVec4(255.0f / 0.0f, 255.0f / 255.0f, 0.0f / 255.0f, 1.0f), "Đây Là Phần Offset Chức Năng Có thể bật tắt");

ImGui::Checkbox(" Nạp Đạn Nhanh ", &camcao);
ImGui::SameLine();
ImGui::Checkbox(" Cam Xa", &CHUV);

            ImGui::EndGroupPanel();

             ImGui::EndTabItem();
                 
             }

            if (ImGui::BeginTabItem(ICON_FA_USER "CÀI ĐẶT"))
                    {

                ImGui::Checkbox("Ẩn Hack", &StreamerMode);

                if (ImGui::Button("Fix Login"))
    {
        self.mtkView.hidden = YES;
        MenDeal = NO;
        timer(30) {
            self.mtkView.hidden = NO;
            MenDeal = YES;
        });
    }      

    ImGui::TextColored(ImColor(0, 255, 0), "NgocBach");
     ImGui::Separator();
        if (ImGui::BeginCombo(ENCRYPT("Style"), selectedStyle.c_str())) {
            if (ImGui::Selectable(ENCRYPT("Light"))) {
ImGui::StyleColorsLight();
                selectedStyle = "Light";
            }
/*
            if (ImGui::Selectable(ENCRYPT("Green"))) {
ImGui::StyleColorsGreen();
                selectedStyle = "Green";
            }
*/
            if (ImGui::Selectable(ENCRYPT("Dark"))) {
ImGui::StyleColorsDark();
selectedStyle = "Dark";
            }
            if (ImGui::Selectable(ENCRYPT("DarkMode"))) {
ImGui::StyleColorsDarkMode();
selectedStyle = "DarkMode";
            }
            if (ImGui::Selectable(ENCRYPT("Classic"))) {
ImGui::StyleColorsClassic();
selectedStyle = "Classic";
            }
            ImGui::EndCombo();
        }


             ImGui::EndTabItem();
                 
             }



       ImGui::EndTabBar();
            ImGui::End();
}
}

        if (cc && !hasGhostBeenDrawn) {
            [self ghost];
            [self activehack];
        } else if (!cc) {
            [self removeGhost];
        }

DrawEsp();
    ImGuiStyle& style = ImGui::GetStyle();
        style.Colors[ImGuiCol_WindowBg].w = 0.9f;  
        style.FrameRounding = 15.0f;
        style.GrabMinSize = 7.0f;
        style.PopupRounding = 2.0f;
        style.ScrollbarRounding = 13.0f;
        style.ScrollbarSize = 20.0f;
        style.TabBorderSize = 0.6f;
        style.TabRounding = 6.0f;
        style.WindowRounding = 2.0f;
        style.Alpha = 1.0f;
        style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
            
            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);

            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:view.currentDrawable];
            
        }
        [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

void DrawAimbotTab() {
    static int selectedAimWhen = AimWhen; // Biến lưu giá trị AimWhen đã chọn

    ImGui::SliderInt("", &AimDis, 180.0f, 200.0f, "Khoảng Cách AIM [ %.1f ]");
    
    // Combo box cho AimWhen
    const char* aimWhenOptions[] = {"Luôn luôn", "Khi bắn", "Khi Ngắm"};
    ImGui::Combo("", &selectedAimWhen, aimWhenOptions, IM_ARRAYSIZE(aimWhenOptions));

    // Cập nhật AimWhen từ selectedAimWhen
    AimWhen = selectedAimWhen;
}

@end