#include "LoadView/Includes.h"
#import "LoadView/DTTJailbreakDetection.h"
#import "Security/oxorany/oxorany_include.h"
#import "Security/oxorany/oxorany.h"
#include <Foundation/Foundation.h>
#include <libgen.h>
#include <mach-o/dyld.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>
#include <mach/vm_page_size.h>
#include <unistd.h>
#include <array>
#include <deque>
#include <map>
#include <vector>
#import "Utils/NakanoYotsuba.h"
#import "imgui/Il2cpp.h"
#import "LoadView/Icon.h"
#import "imgui/stb_image.h"
#import "Utils/Macros.h"
#include "hook/hook.h"
#import "imgui/CaptainHook.h"
#include "Utils/hack/Vector3.h"
#include "Utils/hack/Vector2.h"
#include "Utils/hack/Quaternion.h"
#include "Utils/hack/Monostring.h"
#include "Utils/Esp.h"
#import "imgui/imgui_additional.h"
#import "mahoa.h"
#import "JRMemory.framework/Headers/MemScan.h"
#include <CoreFoundation/CoreFoundation.h>


#define kWidth [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale


UIWindow *mainWindow;
UIButton *menuView;
using namespace IL2Cpp;
@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;

- (void)ghost;
- (void)removeGhost; 
- (void)switchIsChanged:(UISwitch *)SW1;
- (void)text;
@end

UIView *view;
NSString *jail;
NSString *namedv;
NSString *deviceType;
NSString *bundle;
NSString *ver;

NSUserDefaults *saveSetting = [NSUserDefaults standardUserDefaults];
NSFileManager *fileManager1 = [NSFileManager defaultManager];
NSString *documentDir1 = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];

static float tabContentOffsetY[5] = {20.0f, 20.0f, 20.0f, 20.0f, 20.0f}; 
static float tabContentAlpha[5] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f}; 
static int selectedTab = 0;
static int lastSelectedTab = -1; 

const float TAB_CONTENT_ANIMATION_SPEED = 8.0f;
const float BUTTON_WIDTH = 105.0f;
const float BUTTON_HEIGHT = 33.0f;

void AnimateTabContent(int index, bool isActive) {
    if (isActive) {
        if (tabContentOffsetY[index] > 0.0f) {
            tabContentOffsetY[index] -= ImGui::GetIO().DeltaTime * TAB_CONTENT_ANIMATION_SPEED * 20.0f;
            if (tabContentOffsetY[index] < 0.0f) {
                tabContentOffsetY[index] = 0.0f;
            }
        }
        if (tabContentAlpha[index] < 1.0f) {
            tabContentAlpha[index] += ImGui::GetIO().DeltaTime * TAB_CONTENT_ANIMATION_SPEED;
            if (tabContentAlpha[index] > 1.0f) {
                tabContentAlpha[index] = 1.0f;
            }
        }
    } else {
        if (tabContentOffsetY[index] < 20.0f) {
            tabContentOffsetY[index] += ImGui::GetIO().DeltaTime * TAB_CONTENT_ANIMATION_SPEED * 20.0f;
            if (tabContentOffsetY[index] > 20.0f) {
                tabContentOffsetY[index] = 20.0f;
            }
        }
        if (tabContentAlpha[index] > 0.0f) {
            tabContentAlpha[index] -= ImGui::GetIO().DeltaTime * TAB_CONTENT_ANIMATION_SPEED;
            if (tabContentAlpha[index] < 0.0f) {
                tabContentAlpha[index] = 0.0f;
            }
        }
    }
}


@implementation ImGuiDrawView

ImFont* _espFont;
ImFont *_iconFont;

BOOL hasGhostBeenDrawn = NO; // Biến cờ kiểm soát việc vẽ menu Ghost
bool camcao = false;
float CAMCAO(void *instance) {
     if (camcao) {
         return 100;
     }else{
    return 0;
}
}

bool CHUV = false;
int chuV(void *instance) {
     if (CHUV) {
         return 1;
     }else{
    return 0;
}
}
bool camxa = false; 
float CamXa(void *instance) {
    if (camxa > 0.0) {
        return 100.0; 
    } else {
        return 60.0;
    }
}

bool Norecoill = false;
float abc(void *instance) {
     if (Norecoill) {
         return 100.0;
     }else{
    return 1;
}
}

bool BlockHost = false;  // Biến điều khiển trạng thái checkbox
bool cc = false; 
bool danthang = false;
bool Aimlock = false;
bool aim180 = false;
bool speedx30 = false;
bool rss = false;
bool norecoil = false;
bool aimscopev2 = false;
bool tawm = false;
bool ndn = false;
bool Guest(void* _this){
    if (rss){
      return true; 
    }
}
-(void)text{
    mainWindow = [[UIApplication sharedApplication] keyWindow];
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = CGRectGetWidth(screenBounds);
    CGFloat screenHeight = CGRectGetHeight(screenBounds); 

    UILabel *t = [[UILabel alloc] init];
    [t setBackgroundColor:[UIColor clearColor]];
    t.layer.cornerRadius = 10;
    t.textAlignment = NSTextAlignmentLeft;

    NSString *encodedString = @"4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI4paI";
    NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:encodedString options:0];
    NSString *decodedString = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];

    NSLog(@"Decoded string: %@", decodedString);

    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:decodedString];
    NSUInteger length = attributedText.length;
    NSArray<UIColor *> *colors = @[[UIColor blackColor]];
    for (NSUInteger i = 0; i < length; i++) {
        UIColor *color = colors[i % colors.count];
        [attributedText addAttribute:NSForegroundColorAttributeName value:color range:NSMakeRange(i, 1)];
    }

    UIFont *font = [UIFont fontWithName:@"AvenirNext-HeavyItalic" size:8];
    [attributedText addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, length)];

    [t setAttributedText:attributedText];
    [t sizeToFit];

    CGFloat labelX = 10;
    CGFloat labelY = screenHeight - CGRectGetHeight(t.frame);
    CGRect labelFrame = CGRectMake(labelX, labelY, CGRectGetWidth(t.frame), CGRectGetHeight(t.frame));
    [t setFrame:labelFrame];

    [mainWindow addSubview:t];


    UILabel *myLabel = [[UILabel alloc] initWithFrame:CGRectMake(-40, 0, 300, 20)]; 
    myLabel.textColor = [UIColor cyanColor];
    myLabel.font = [UIFont fontWithName:@"AvenirNext-HeavyItalic" size:15];
    myLabel.numberOfLines = 1;
    myLabel.text = [NSString stringWithUTF8String:oxorany("")];
    myLabel.textAlignment = NSTextAlignmentCenter;
    myLabel.shadowColor = [UIColor whiteColor];
    myLabel.shadowOffset = CGSizeMake(1.0,1.0); 
    myLabel.backgroundColor = [UIColor clearColor];
    [mainWindow addSubview:myLabel];
}

- (void)ghost {  
    mainWindow = [[UIApplication sharedApplication] keyWindow];  

    if (!menuView) {  
        // Tạo menuView với nền tròn màu đen nhạt  
        menuView = [UIButton buttonWithType:UIButtonTypeCustom];  
        menuView.frame = CGRectMake(305, 265, 50, 50);  
        menuView.layer.cornerRadius = menuView.bounds.size.width / 2; // Hình tròn  
        menuView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.6]; // Nền đen nhạt  
        menuView.alpha = 1.0f;  

        // Đảm bảo chỉ thêm vào cửa sổ chính một lần  
        [mainWindow addSubview:menuView];  

        // Thêm sự kiện kéo nút sử dụng UIPanGestureRecognizer  
        UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];  
        [menuView addGestureRecognizer:panGesture];  

        // Thêm nhãn cho trạng thái Aimbot  
        UILabel *aimLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 50, 50)]; // Kích thước 50x50 cho chữ
        aimLabel.font = [UIFont fontWithName:@"CourierNewPS-BoldMT" size:16];  
        aimLabel.textAlignment = NSTextAlignmentCenter; // Canh giữa  
        aimLabel.backgroundColor = [UIColor clearColor]; // Không có nền  
        aimLabel.tag = 100; // Gán thẻ để truy xuất sau  

        // Căn giữa nhãn trong menuView  
        aimLabel.center = CGPointMake(menuView.bounds.size.width / 2, menuView.bounds.size.height / 2);  

        // Thêm nhãn vào menuView  
        [menuView addSubview:aimLabel];  

        // Đặt văn bản cho nhãn  
        aimLabel.text = @"AIM";   
        aimLabel.textColor = [UIColor redColor]; // Màu chữ bắt đầu là đỏ (tắt)  

        // Tạo nút "AIM" nhỏ lại (kích thước 30x30 thay vì 70x70)  
        UIButton *aimButton = [UIButton buttonWithType:UIButtonTypeCustom];  
        aimButton.frame = CGRectMake(0, 0, 30, 30); // Kích thước nút nhỏ lại  
        aimButton.layer.cornerRadius = aimButton.bounds.size.width / 2; // Vẫn giữ hình tròn  
        aimButton.backgroundColor = [UIColor clearColor]; // Nền trong suốt  
        [aimButton addTarget:self action:@selector(switchIsChanged:) forControlEvents:UIControlEventTouchUpInside];  

        // Căn giữa nút "AIM" nhỏ trong menuView  
        aimButton.center = CGPointMake(menuView.bounds.size.width / 2, menuView.bounds.size.height / 2);  

        // Thêm nút vào menuView  
        [menuView addSubview:aimButton];  

        hasGhostBeenDrawn = YES; // Đánh dấu menu đã được vẽ  
    }  
}

// Phương thức gọi khi Aimbot bị bật/tắt  
- (void)switchIsChanged:(UIButton *)button {  
    dispatch_async(dispatch_get_main_queue(), ^{  
        UILabel *aimLabel = (UILabel *)[[button superview] viewWithTag:100]; // Tìm nhãn  

        if ([aimLabel.textColor isEqual:[UIColor redColor]]) {  
            // Bật Aimbot  
            Aimbot = true;  
            aimLabel.textColor = [UIColor greenColor]; // Đổi màu chữ thành xanh  
        } else {  
            // Tắt Aimbot  
            Aimbot = false;  
            aimLabel.textColor = [UIColor redColor]; // Đổi màu chữ thành đỏ  
        }  
    });  
}  

// Phương thức gọi khi xóa menu  
- (void)removeGhost {  
    if (menuView) {  
        [menuView removeFromSuperview];  
        menuView = nil;  
        hasGhostBeenDrawn = NO;  
    }  
}  

// Phương thức xử lý kéo  
- (void)handlePan:(UIPanGestureRecognizer *)gesture {  
    CGPoint translation = [gesture translationInView:mainWindow];  
    CGPoint newCenter = CGPointMake(gesture.view.center.x + translation.x, gesture.view.center.y + translation.y);  
    gesture.view.center = newCenter; // Cập nhật vị trí của nút  
    [gesture setTranslation:CGPointZero inView:mainWindow]; // Đặt lại translation về 0  
} 

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{

    [self clm];

    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    // Style Setup


    ImFontConfig config;
    ImFontConfig icons_config;
    config.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2;
    icons_config.OversampleV = 2;

    static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };

    NSString *fontPath = nssoxorany("/System/Library/Fonts/Core/AvenirNext.ttc");

    _espFont = io.Fonts->AddFontFromFileTTF(fontPath.UTF8String, 30.f, &config, io.Fonts->GetGlyphRangesVietnamese());

    _iconFont = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 19.0f, &icons_config, icons_ranges);

    _iconFont->FontSize = 5;
    io.FontGlobalScale = 0.5f;

    ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
}

+ (BOOL)isMenuShowing {
    return MenDeal;
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

-(void)clm
{

ver = [[[NSBundle mainBundle] infoDictionary] objectForKey:nssoxorany("CFBundleShortVersionString")];

bundle = [[NSBundle mainBundle] bundleIdentifier];

namedv = [[UIDevice currentDevice] name];
deviceType = [[UIDevice currentDevice] model];

if ([DTTJailbreakDetection isJailbroken]) {
jail = nssoxorany("Jailbroken");

}else{
jail = nssoxorany("Not Jailbroken Or Hidden Jailbreak");

}
}

- (void)loadView
{
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    if (!self.mtkView.device) {
        return;
    }
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    [self text];



}
static bool MenDeal = false;
static bool StreamerMode = true; // Khởi tạo giá trị ban đầu là false (chế độ streamer tắt)
// Hàm hiển thị thông tin liên lạc
void ShowContactInfo() {
    ImGui::TextColored(ImVec4(255.0f / 0.0f, 255.0f / 255.0f, 0.0f / 255.0f, 1.0f), "CONTACT");
    ImGui::Text(oxorany("Telegram: @okiokiokioki123"));
    ImGui::Text(oxorany("ADMIN: TLX Modder"));
}

// Hàm hiển thị thông tin hack
void ShowHackInfo() {
    ImGui::TextColored(ImVec4(255.0f / 0.0f, 255.0f / 255.0f, 0.0f / 255.0f, 1.0f), "Mua HACK INBOX");
    ImGui::Text(oxorany("Zalo: 0343458810"));


    }
    

// Hàm hiển thị quảng cáo (thay thế bằng quảng cáo thật)
void ShowAdvertisement() {
    ImGui::TextColored(ImVec4(255.0f / 0.0f, 255.0f / 255.0f, 0.0f / 255.0f, 1.0f), "# ADVERTISEMENT");
    ImGui::Text(oxorany("Hack By TLX"));
}

- (void)drawInMTKView:(MTKView*)view
{

    hideRecordTextfield.secureTextEntry = StreamerMode;

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
        
        if (MenDeal == true) 
        {
            [self.view setUserInteractionEnabled:YES];
            [self.view.superview setUserInteractionEnabled:YES];
            [menuTouchView setUserInteractionEnabled:YES];
        } 
        else if (MenDeal == false) 
        {
           
            [self.view setUserInteractionEnabled:NO];
            [self.view.superview setUserInteractionEnabled:NO];
            [menuTouchView setUserInteractionEnabled:NO];

        }

Attach();

        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil)
        {
            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            [renderEncoder pushDebugGroup:nssoxorany("ImGui Jane")];

            ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();

            CGFloat width = 480;
            CGFloat height = 330;
            ImGui::SetNextWindowPos(ImVec2((kWidth - width) / 2, (kHeight - height) / 2), ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_FirstUseEver);



            
                  if (MenDeal) {
            ImGui::Begin(ENCRYPT("TLX Modder - Zalo 0343458810"), &MenDeal);
            
            ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 2.0f);

            // Tab Buttons
            ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 0 ? ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f) : ImVec4(30 / 255.0f, 30 / 255.0f, 30 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 0 ? ImVec4(0, 0, 0, 1.0f) : ImVec4(200 / 255.0f, 200 / 255.0f, 200 / 255.0f, 1.0f));
             if 
(ImGui::Button(ICON_FA_HOME " HOME", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) {
                selectedTab = 0;
            }
            ImGui::PopStyleColor(4);

            ImGui::SameLine();

            ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 1 ? ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f) : ImVec4(30 / 255.0f, 30 / 255.0f, 30 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 1 ? ImVec4(0, 0, 0, 1.0f) : ImVec4(200 / 255.0f, 200 / 255.0f, 200 / 255.0f, 1.0f));

            
         if (ImGui::Button(ICON_FA_CROSSHAIRS " ESP + AIMBOT", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) 
{
                
                selectedTab = 2;
            }
            ImGui::PopStyleColor(4);

            ImGui::SameLine();

            ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 3 ? ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f) : ImVec4(30 / 255.0f, 30 / 255.0f, 30 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 3 ? ImVec4(0, 0, 0, 1.0f) : ImVec4(200 / 255.0f, 200 / 255.0f, 200 / 255.0f, 1.0f));
            if (ImGui::Button(ICON_FA_ID_CARD " Info", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) 
{
                selectedTab = 3;
            }
            ImGui::PopStyleColor(4);

            

            // ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 4 ? ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f) : ImVec4(30 / 255.0f, 30 / 255.0f, 30 / 255.0f, 1.0f));
            // ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f));
            // ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(205 / 255.0f, 250 / 255.0f, 0 / 255.0f, 1.0f));
            // ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 4 ? ImVec4(0, 0, 0, 1.0f) : ImVec4(200 / 255.0f, 200 / 255.0f, 200 / 255.0f, 1.0f));
            // if (ImGui::Button(ICON_FA_INFO_CIRCLE " Info", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) {
            //     selectedTab = 4; // Chọn tab "Info"
            // }
            // ImGui::PopStyleColor(4);

            ImGui::PopStyleVar(2);

            
            if (lastSelectedTab != selectedTab) {
               
                for (int i = 0; i < 4; ++i) { 
                    tabContentOffsetY[i] = 20.0f;
                    tabContentAlpha[i] = 0.0f;
                }
                lastSelectedTab = selectedTab;
            }
            AnimateTabContent(selectedTab, true);

            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(12, 8 + tabContentOffsetY[selectedTab]));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, tabContentAlpha[selectedTab]);

            // Tab Content
            if (selectedTab == 2) {
                ImGui::Spacing();
                //ImGui::Checkbox("Bật AimBot", &Aimbot);

                ImGui::Checkbox("Bật AimBot", &cc);

ImGui::SameLine(200);

//ImGui::Checkbox(" FOV", &Fov); 
                
                //ImGui::SliderInt("", &AimbotFOV, 0.0f, 360.0f, "%.0f");

        ImGui::Checkbox("FOV", &Fov);
ImGui::SameLine();

ImGui::SliderInt("", &circle_size, 0, 360);
                DrawAimbotTab();

    ImGui::TextColored(ImVec4(255.0f / 0.0f, 255.0f / 255.0f, 0.0f / 255.0f, 1.0f), "Đây Là Phần Offset Chức Năng Có thể bật tắt");
                

ImGui::Checkbox(ENCRYPT("Đổi Súng Nhanh"), &Norecoill);  ImGui::SameLine();   
                    ImGui::Checkbox(" Cam Xa ", &camxa);ImGui::SameLine();
                                        ImGui::Checkbox(" Nạp Đạn Nhanh ", &camcao);
                                        ImGui::Checkbox(" Bắn Di Chuyển", &CHUV);

                ImGui::Spacing();
                ImGui::Checkbox(" Bật ESP", &ESPEnable);
                ImGui::SameLine(150);  // Điều chỉnh khoảng cách ngang giữa các checkbox
                ImGui::ColorEdit3(oxorany("Color ESP"), &*(float*)colorEsp, ImGuiColorEditFlags_NoInputs);


                ImGui::SliderInt(" ", &sliderDistanceValue, 200.0f, 700.0f, "Khoảng Cách ESP [ %.3f ]");

                ImGui::Checkbox("Line", &ESPLine);

                ImGui::Checkbox("Xương", &bone);

                ImGui::Checkbox("Box", &ESPBox);

                ImGui::Checkbox("Name", &ESPName); 
                
ImGui::Checkbox("Health", &ESPHealth); 

ImGui::Checkbox("Count", &ESPCount);                 

                
            } else if (selectedTab == 0) {
                ImGui::Checkbox("Ẩn Hack", &StreamerMode);


                if (ImGui::Button("Fix Login"))
    {
        self.mtkView.hidden = YES;
        MenDeal = NO;
        timer(30) {
            self.mtkView.hidden = NO;
            MenDeal = YES;
        });
    }      


                ImGui::Spacing();
            } else if (selectedTab == 3) { 
                ImGui::Spacing();
                ImGui::BeginChild("MoreContent", ImVec2(0, 0), true);
               
                ShowContactInfo(); 
                ShowHackInfo(); // 
                ShowAdvertisement(); 
                ImGui::EndChild();
                ImGui::Spacing();

            } 

            ImGui::PopStyleVar(2);

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();

            ImGui::End();
}
        if (cc && !hasGhostBeenDrawn) { // Kiểm tra cc và biến cờ
            [self ghost];
        } else if (!cc) {
            [self removeGhost];
        }
ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
DrawEsp();
            ImGuiStyle* style = &ImGui::GetStyle();
    ImVec4* colors = style->Colors;

                colors[ImGuiCol_Text]                   = ImVec4(0.00f, 1.00f, 0.00f, 1.000f);  //màu chữ văn bản

           colors[ImGuiCol_TextDisabled]           = ImVec4(0.500f, 0.500f, 0.500f, 1.000f);
           colors[ImGuiCol_WindowBg]               = ImVec4(0.00f, 0.00f, 0.00f, 0.30f);
           colors[ImGuiCol_ChildBg]                = ImVec4(0.280f, 0.280f, 0.280f, 0.000f);
           colors[ImGuiCol_PopupBg]                = ImVec4(0.313f, 0.313f, 0.313f, 1.000f);

           colors[ImGuiCol_Border]                 = ImVec4(0.00f, 1.00f, 0.00f, 1.000f); // grean pastel //màu bo viền các nút và menu..grean
           colors[ImGuiCol_BorderShadow]           = ImVec4(0.000f, 0.000f, 0.000f, 0.000f);

       //màu nền khung checkbox
           colors[ImGuiCol_FrameBg]                = ImVec4(0.0f, 0.0f, 0.0f, 1.000f); // Đen,nền nút
           colors[ImGuiCol_FrameBgHovered]         = ImVec4(0.200f, 0.200f, 0.200f, 1.000f);
           colors[ImGuiCol_FrameBgActive]          = ImVec4(0.0f, 0.0f, 0.0f, 1.000f); // Đen
           colors[ImGuiCol_TitleBg]                = ImVec4(0.0f, 0.0f, 0.0f, 1.000f); // Đen
           colors[ImGuiCol_TitleBgActive]          = ImVec4(0.0f, 0.0f, 0.0f, 1.000f); // Đen
           colors[ImGuiCol_TitleBgCollapsed]       = ImVec4(0.148f, 0.148f, 0.148f, 1.000f);
           colors[ImGuiCol_MenuBarBg]              = ImVec4(0.0f, 1.0f, 0.0f, 1.000f); // xanh
           colors[ImGuiCol_ScrollbarBg]            = ImVec4(0.160f, 0.160f, 0.160f, 1.000f);
           colors[ImGuiCol_ScrollbarGrab]          = ImVec4(0.0f, 1.0f, 0.0f, 1.000f);//Xanh


           colors[ImGuiCol_ScrollbarGrabHovered]   = ImVec4(0.277f, 0.277f, 0.277f, 1.000f);
           colors[ImGuiCol_ScrollbarGrabActive]    = ImVec4(0.0f, 0.0f, 0.0f, 1.000f); // Đen
           colors[ImGuiCol_CheckMark]              = ImVec4(0.000f, 1.000f, 0.000f, 1.000f);//Dấu tick/Xanh
           colors[ImGuiCol_SliderGrab]             = ImVec4(0.0f, 1.0f, 0.0f, 1.000f);//xanh
           colors[ImGuiCol_SliderGrabActive]       = ImVec4(1.000f, 1.391f, 1.000f, 1.000f);//Xanh
           colors[ImGuiCol_Button]                 = ImVec4(0.0f, 1.0f, 0.0f, 1.000f); //Xanh
           colors[ImGuiCol_ButtonHovered]          = ImVec4(1.000f, 1.000f, 1.000f, 0.156f);
           colors[ImGuiCol_ButtonActive]           = ImVec4(1.0f, 1.0f, 1.0f, 1.000f); // Đen
           colors[ImGuiCol_Header]                 = ImVec4(0.313f, 0.313f, 0.313f, 1.000f);
           colors[ImGuiCol_HeaderHovered]          = ImVec4(0.469f, 0.469f, 0.469f, 1.000f);
           colors[ImGuiCol_HeaderActive]           = ImVec4(0.469f, 0.469f, 0.469f, 1.000f);
           colors[ImGuiCol_Separator]              = colors[ImGuiCol_Border];
           colors[ImGuiCol_SeparatorHovered]       = ImVec4(0.391f, 0.391f, 0.391f, 1.000f);
           colors[ImGuiCol_SeparatorActive]        = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
           colors[ImGuiCol_ResizeGrip]             = ImVec4(0.000f, 0.000f, 0.000f, 1.250f);//Mở Rộng imgui
           colors[ImGuiCol_ResizeGripHovered]      = ImVec4(0.000f, 0.000f, 0.000f, 0.670f);//Mở Rộng imgui
           colors[ImGuiCol_ResizeGripActive]       = ImVec4(0.000f, 1.000f, 0.000f, 1.000f);//Mở Rộng imgu
           colors[ImGuiCol_TabHovered]             = ImVec4(0.0f, 0.0f, 0.0f, 1.000f); // Đen
           colors[ImGuiCol_TabActive]              = ImVec4(0.0f, 0.0f, 0.0f, 1.000f); // Đen
           colors[ImGuiCol_TabUnfocused]           = ImVec4(0.098f, 0.098f, 0.098f, 1.000f);
           colors[ImGuiCol_TabUnfocusedActive]     = ImVec4(0.195f, 0.195f, 0.195f, 1.000f);
           colors[ImGuiCol_PlotLines]              = ImVec4(0.469f, 0.469f, 0.469f, 1.000f);
           colors[ImGuiCol_PlotLinesHovered]       = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
           colors[ImGuiCol_PlotHistogram]          = ImVec4(0.586f, 0.586f, 0.586f, 1.000f);
           colors[ImGuiCol_PlotHistogramHovered]   = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
           colors[ImGuiCol_TextSelectedBg]         = ImVec4(1.000f, 1.000f, 1.000f, 0.156f);
           colors[ImGuiCol_DragDropTarget]         = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
           colors[ImGuiCol_NavHighlight]           = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
           colors[ImGuiCol_NavWindowingHighlight]  = ImVec4(1.000f, 0.391f, 0.000f, 1.000f);
           colors[ImGuiCol_NavWindowingDimBg]      = ImVec4(0.000f, 0.000f, 0.000f, 0.586f);
           colors[ImGuiCol_ModalWindowDimBg]       = ImVec4(0.000f, 0.000f, 0.000f, 0.586f);
                
    style->ChildRounding = 4.0f;
    style->FrameBorderSize = 1.0f; // bo viền button,checkbox
    style->FrameRounding = 8.0f;
    style->GrabMinSize = 7.0f;
    style->PopupRounding = 2.0f;
    style->ScrollbarRounding = 12.0f;
    style->ScrollbarSize = 13.0f;
    style->WindowRounding = 4.0f;
            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);

            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:view.currentDrawable];
            
        }
        [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}


ImDrawList* getDrawList(){
    ImDrawList *drawList;
    drawList = ImGui::GetBackgroundDrawList();
    return drawList;
};

void DrawAimbotTab() {
    static int selectedAimWhen = AimWhen; // Biến lưu giá trị AimWhen đã chọn

    
    ImGui::SliderInt("", &AimDis, 180.0f, 200.0f, "Khoảng Cách AIM [ %.1f ]");
    
    // Combo box cho AimWhen
    const char* aimWhenOptions[] = {"Luôn luôn", "Khi bắn", "Khi Ngắm"};
    ImGui::Combo("", &selectedAimWhen, aimWhenOptions, IM_ARRAYSIZE(aimWhenOptions));

    // Cập nhật AimWhen từ selectedAimWhen
    AimWhen = selectedAimWhen;
}

void hooking() {
    void* address[] = {  

(void*)getRealOffset(ENCRYPTOFFSET("0x103E526F0")), 
        (void*)getRealOffset(ENCRYPTOFFSET("0x10529A408")), 
        //(void*)getRealOffset(ENCRYPTOFFSET("0x1022D3F80")), 
              (void*)getRealOffset(ENCRYPTOFFSET("0x1040D6610")), 

        (void*)getRealOffset(ENCRYPTOFFSET("0x10525CC58")), 
        (void*)getRealOffset(ENCRYPTOFFSET("0x1052620FC")), 
        (void*)getRealOffset(ENCRYPTOFFSET("0x1052A23A0")) 
       

    };
    void* function[] = {
        (void*)CamXa,
        (void*)Update,
        //(void*)Guest,
        (void*)CAMCAO,
        (void*)abc,
        (void*)OnDestroy,
        (void*)chuV

    };
    hook(address, function, 6);
_GetHeadPositions = (void*(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BECB8"));
_newHipMods = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BEE08"));
_GetLeftAnkleTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF13C"));
_GetRightAnkleTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF1E0"));
_GetLeftToeTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF284"));
_GetRightToeTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF328"));
_getLeftHandTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C0E8"));
_getRightHandTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C194"));
_getLeftForeArmTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C238"));
_getRightForeArmTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C2DC"));

    Local = (bool (*)(void *))getRealOffset(ENCRYPTOFFSET("0x105258C80"));                              
    Team = (bool (*)(void *))getRealOffset(ENCRYPTOFFSET("0x10526D118"));                               
    get_CurHP = (int (*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052A8A30"));                           
    get_MaxHP = (int(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052A8AD8"));                            
    get_position = (Vector3(*)(void *))getRealOffset(ENCRYPTOFFSET("0x105F3D46C"));                     
    WorldToViewpoint = (Vector3(*)(void *, Vector3, int))getRealOffset(ENCRYPTOFFSET("0x105EF6394"));  
    get_main = (void *(*)())getRealOffset(ENCRYPTOFFSET("0x105EF6D08"));                                
    get_transform = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x105EF8D78"));                     
}

void *hack_thread(void *) {
    sleep(5);
    hooking();
    pthread_exit(nullptr);
    return nullptr;
}

void __attribute__((constructor)) initialize() {
    pthread_t hacks;
    pthread_create(&hacks, NULL, hack_thread, NULL); 
}

@end